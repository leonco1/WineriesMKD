package com.example.diansdomasna3.Model.enumerations;

public enum     WineType {
    RED,
    WHITE,
    ROSE,
    SPARKLING,
    DESSERT,
    FORTIFIED,
}
