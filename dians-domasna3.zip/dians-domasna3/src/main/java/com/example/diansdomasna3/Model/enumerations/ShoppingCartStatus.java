package com.example.diansdomasna3.Model.enumerations;

public enum ShoppingCartStatus {
    CREATED,
    CANCELED,
    FINISHED
}

