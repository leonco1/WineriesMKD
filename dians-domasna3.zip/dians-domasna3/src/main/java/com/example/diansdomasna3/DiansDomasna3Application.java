package com.example.diansdomasna3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiansDomasna3Application {

    public static void main(String[] args) {
        SpringApplication.run(DiansDomasna3Application.class, args);
    }

}
