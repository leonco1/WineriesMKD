package com.example.diansdomasna3.repository.jpa;

import com.example.diansdomasna3.Model.Review;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReviewRepository extends JpaRepository<Review,Long> {


}
