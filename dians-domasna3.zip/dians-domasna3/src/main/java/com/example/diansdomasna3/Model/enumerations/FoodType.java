package com.example.diansdomasna3.Model.enumerations;

public enum FoodType {
    Meat,
    Fish,
    Cheese,
    CuredMeat,
    Chocolate,
    Nuts
}
